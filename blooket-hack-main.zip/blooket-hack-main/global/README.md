# Support discord server: https://glizzers.xyz/discord

# global

All these cheats in the folder can be used outside games

# addTokens.js

note: **This cheat also includes adding max xp for the day**

### Get the script from the file [addTokens.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/global/addTokens.js) or https://schoolcheats.net/blooket

# floodGame.js

### Get the script from the file [floodGame.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/global/floodGame.js) or https://schoolcheats.net/blooket

# getAllBlooksInGame.js

### Get the script from the file [getAllBlooksInGame.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/global/getAllBlooksInGame.js) or https://schoolcheats.net/blooket

# getAllBlooks.js

note: **This script is a spoofer.**

### Get the script from the file [getAllBlooksInGame.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/global/getAllBlooks.js)

# getEveryAnswerCorrect.js

### Get the script from the file [getEveryAnswerCorrect.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/global/getEveryAnswerCorrect.js) or https://schoolcheats.net/blooket

# spamOpenBoxes.js

### Get the script from the file [spamOpenBoxes.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/global/spamOpenBoxes.js) or https://schoolcheats.net/blooket

# sellDupeBlooks.js

### Get the script from the file [sellDupeBlooks.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/global/sellDupeBlooks.js) or https://schoolcheats.net/blooket
