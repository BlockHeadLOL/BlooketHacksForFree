# py

This Python script adds tokens and XP to your account every day.

- Install the latest Python release from https://www.python.org/downloads/
- Open `addTokensDaily.py` and change the first to variables to your username/email and password
- In your command line type `cd` to navigate to the directory where the `addCurrenciesDaily.py` is located. For example: `cd downloads/blooket/addCurrenciesDaily.py`
- type `pip install -r requirements.txt`
- type `python addTokensDaily.py`