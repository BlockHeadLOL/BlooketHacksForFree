# All the Versions of The Blooket Hack

**Scroll down for the older versions**

## Blooket Hack v4

Unreleased

### Shorter Versions

- v3.9 - Added beta validation checks to use the Blooket hack and hopeful spoof csp-report request (`document-uri`)
- v3.5 - Fixed major CSP header problems

## Blooket Hack v3

- Major code revamp (Code revamp for only me of course cause y'all can't see the code since its obfuscated 😆)
- fixed all the error handler (links)

## Blooket Hack v2

- Tons of bug fixes
- A lot of new scripts for more/new game modes
- Added new out of game scripts

## Blooket Hack v1

Intital Release!