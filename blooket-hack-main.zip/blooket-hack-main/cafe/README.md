# Support discord server: https://glizzers.xyz/discord

# cafe

This cheat only works in cafe game mode!

# getCoins.js

### Get the script from the file [getCoins.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/cafe/getCoins.js) or https://schoolcheats.net/blooket


# infiniteFoodLevel.js

### Get the script from the file [infiniteFoodLevel.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/cafe/infiniteFoodLevel.js) or https://schoolcheats.net/blooket

# stockInfiniteFood.js

### Get the script from the file [stockInfiniteFood.js](https://raw.githubusercontent.com/glixzzy/blooket-hack/main/cafe/stockInfiniteFood.js) or https://schoolcheats.net/blooket
